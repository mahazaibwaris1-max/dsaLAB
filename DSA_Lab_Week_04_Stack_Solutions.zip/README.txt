DSA LAB WEEK 04 - STACK

Task 1:
- AbstractStack.h contains the generic abstract stack interface.
- myStack.h implements the stack using a dynamically allocated array.
- Task_1.cpp provides the menu for push, pop, top, empty, full and display.

Task 2:
- Uses the same abstract stack structure.
- myStack.h maintains a second internal array for minimum values.
- getMin() returns the minimum element in O(1) time.
- Task_2.cpp includes the minimum element menu option.

Task 3:
- myCarStack.h manages a parking lot with a capacity of 8 cars.
- Cars are removed by temporarily moving cars above the requested car to another stack.
- Task_3.cpp provides the parking lot menu.

Task 4:
- Task_4.cpp provides typing, deleting, undo and redo.
- Two stacks store previous and undone text states.

Code uses basic C++ and contains no comments.
Compile each Task_X.cpp separately. Do not combine all main files into one project.
